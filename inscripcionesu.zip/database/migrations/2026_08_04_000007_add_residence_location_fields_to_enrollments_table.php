<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('enrollments', function (Blueprint $table) {
            $table->foreignId('residence_department_id')->nullable()->after('address')->constrained('departments')->nullOnDelete();
            $table->foreignId('residence_municipality_id')->nullable()->after('residence_department_id')->constrained('municipalities')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('enrollments', function (Blueprint $table) {
            $table->dropConstrainedForeignId('residence_municipality_id');
            $table->dropConstrainedForeignId('residence_department_id');
        });
    }
};
